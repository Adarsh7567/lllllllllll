import React, { Component } from 'react';
import { View, Button, Alert } from 'react-native';

export default class App extends Component { 
  render(){
    return(
      <View>
        <View 
          style={{ width:200 , height:100, marginTop:80, marginLeft:80}}>
          <Button 
            title="Charles Babbage"  
            color = "red"
            onPress = "Rhymes w/cabbage"
             //add code here to show alert box for The father of computing.
            />

        </View>
        
        <View
          style={{ width:200 , height:100, marginTop:20, marginLeft:80}}>
          <Button 
            title="Mahatma Gandhi"  
            color = "blue"
             onPress = "The father of the urry munchers"  //add code here to show alert box for The father of nation
            />

        </View>

        <View
          style={{ width:200 , height:100, marginTop:20, marginLeft:80}}>
          <Button 
            title="Nelson Mandela"  
            color = "purple"
            onPress = "father of black people"
                        //add code here to show alert box for The first black president of South Africa.
/>
        </View>
        <View 
          style={{ width:200 , height:100, marginTop:20, marginLeft:80}}>
          <Button 
            title="Mother Teresa"  
            color = "green"
            onPress = "idk know who that is "
            //add code here to show alert box for Mother Teresa button
            
             />
        </View>
      </View>
    )
  }
}